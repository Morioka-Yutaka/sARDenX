filename P3B73C08 list;

 %put NOTE- ;
 %put NOTE: Data for package sARDenX, version 0.1.1, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-11-11T18:50:13; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(sARDenX) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package sARDenX, version 0.1.1, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

